# Task-3--Car-Price-Prediciton-With-Machine-Learning

1.In this task, I took Car Price dataset and performed Linear Regression and Lasso Regression Algorithms to make model.

2.Many analyses of the dataset were performed.

3.Many visualizations of the dataset were created.

4.Finally, I plotted a graph for actual vs. predicted values.
